//
//  AppDelegate.h
//  CameraDemo
//
//  Created by leju_esf on 2017/7/17.
//  Copyright © 2017年 tsy. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end


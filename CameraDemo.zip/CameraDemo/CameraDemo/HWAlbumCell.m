//
//  HWAlbumCell.m
//  HuaWo
//
//  Created by leju_esf on 2017/7/17.
//  Copyright © 2017年 HW. All rights reserved.
//

#import "HWAlbumCell.h"

@implementation HWAlbumCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end

//
//  HWHardwareCell.m
//  HuaWo
//
//  Created by yjc on 2017/6/2.
//  Copyright © 2017年 HW. All rights reserved.
//

#import "HWHardwareCell.h"

@implementation HWHardwareCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    

    // Configure the view for the selected state
}
- (void)setHighlighted:(BOOL)highlighted animated:(BOOL)animated
{
    
}

@end

//
//  SYVideoListCell.h
//  SYRecordVideoDemo
//
//  Created by leju_esf on 17/3/16.
//  Copyright © 2017年 tsy. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "SYVideoModel.h"
@interface SYVideoListCell : UITableViewCell
@property (nonatomic, strong) SYVideoModel *model;
@end

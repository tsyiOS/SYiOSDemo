//
//  AppDelegate.h
//  InterviewSource
//
//  Created by leju_esf on 16/11/29.
//  Copyright © 2016年 tsy. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

